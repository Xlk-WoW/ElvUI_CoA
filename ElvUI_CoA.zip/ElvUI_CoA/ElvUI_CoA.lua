--[[
	ElvUI_CoA - Conquest of Azeroth (Grimfall) add-on for ElvUI

	Keeps all CoA-specific behaviour OUT of the base ElvUI folder so the same
	ElvUI can be shared with the Classless 3.3.5 realm untouched.

	What it does
	  * Draws spell charge counts (e.g. Chaos Rush 3/3) on ElvUI action buttons.
	    The server exposes charges through GetSpellCharges, but ElvUI's action
	    buttons only read GetActionCount, so the number never shows. We hook
	    LibActionButton's own callbacks (no edits to ElvUI or the library).
	  * Optionally manages the cooldown swipe so a button with charges left
	    doesn't look locked out, and shows the recharge timer at 0 charges.

	Safe on other realms: it only acts on spells for which GetSpellCharges
	returns a maximum greater than 1. Everything else is left alone.

	Commands: /coa
]]

local ADDON_NAME = ...

local LAB = LibStub and LibStub("LibActionButton-1.0-ElvUI", true)
if not LAB then return end

local pairs, tostring, tonumber, type = pairs, tostring, tonumber, type
local GetSpellCharges, GetActionInfo = GetSpellCharges, GetActionInfo

local CoA = CreateFrame("Frame", "ElvUI_CoAFrame")
local TICK = 0.2

local defaults = {
	enabled = true, -- draw charge counts
	swipe = true,   -- manage cooldown swipe for charge spells
}

local function Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage("|cff1784d1ElvUI|r |cffffd100CoA|r: " .. tostring(msg))
end

local function DB()
	return ElvCoADB or defaults
end

-- Resolve the spell id behind a LibActionButton button
local function ButtonSpellID(btn)
	local bt, action = btn._state_type, btn._state_action
	if bt == "action" and action then
		local kind, id, _, globalID = GetActionInfo(action)
		if kind == "spell" then
			return globalID or id
		elseif kind == "macro" then
			return btn:GetSpellId()
		end
	elseif bt == "spell" then
		return action
	end
end

local function GetCharges(spellID)
	if not spellID or not GetSpellCharges then return end
	local cur, max, start, duration = GetSpellCharges(spellID)
	if cur and max and max > 1 then
		return cur, max, start, duration
	end
end

local function Apply(btn, force)
	local db = DB()
	if not db.enabled or not btn or not btn.count then return end

	local cur, max, start, duration = GetCharges(ButtonSpellID(btn))
	if not cur then
		btn.coaCur, btn.coaKey = nil, nil
		return
	end

	if force or btn.coaCur ~= cur then
		btn.count:SetText(cur)
		btn.coaCur = cur
	end

	if not db.swipe or not btn.cooldown then return end

	if cur > 0 then
		-- Charges left: the ability is usable. Clear a long "cooldown" the server
		-- may report for the recharge, but keep the normal 1.5s global cooldown.
		btn.coaKey = nil
		local _, d = btn:GetCooldown()
		if d and d > 1.5 then
			CooldownFrame_SetTimer(btn.cooldown, 0, 0, 0)
			if btn.icon then btn.icon:SetDesaturated(false) end
		end
	else
		-- Out of charges: show the time until the next one
		local key = tostring(start) .. ":" .. tostring(duration)
		if (force or btn.coaKey ~= key) and start and duration and start > 0 and duration > 0 then
			btn.coaKey = key
			CooldownFrame_SetTimer(btn.cooldown, start, duration, 1)
		end
	end
end

-- Hook LibActionButton callbacks (same mechanism ElvUI's own ActionBars use)
local function OnButtonUpdate(_, btn) Apply(btn, true) end
local function OnCooldownUpdate(_, btn) Apply(btn, true) end
LAB.RegisterCallback(CoA, "OnButtonUpdate", OnButtonUpdate)
LAB.RegisterCallback(CoA, "OnCooldownUpdate", OnCooldownUpdate)

-- The server may not fire cooldown events when a charge comes back, so poll lightly
local elapsed = 0
local function OnUpdate(_, e)
	elapsed = elapsed + e
	if elapsed < TICK then return end
	elapsed = 0
	if not DB().enabled then return end
	for btn in pairs(LAB.activeButtons) do
		if btn:IsShown() then Apply(btn, false) end
	end
end

local function RefreshAll()
	for btn in pairs(LAB.activeButtons) do Apply(btn, true) end
end

CoA:RegisterEvent("ADDON_LOADED")
CoA:RegisterEvent("PLAYER_ENTERING_WORLD")
CoA:SetScript("OnEvent", function(self, event, name)
	if event == "ADDON_LOADED" and name == ADDON_NAME then
		ElvCoADB = ElvCoADB or {}
		for k, v in pairs(defaults) do
			if ElvCoADB[k] == nil then ElvCoADB[k] = v end
		end
		self:SetScript("OnUpdate", OnUpdate)
	elseif event == "PLAYER_ENTERING_WORLD" then
		RefreshAll()
	end
end)

-- Slash commands
SLASH_ELVUICOA1 = "/coa"
SlashCmdList["ELVUICOA"] = function(msg)
	msg = (msg or ""):lower():match("^%s*(.-)%s*$")
	local db = DB()

	if msg == "on" or msg == "off" then
		db.enabled = (msg == "on")
		Print("charge display " .. (db.enabled and "enabled" or "disabled") .. ". Type /reload to fully apply.")
		if db.enabled then RefreshAll() end
	elseif msg == "swipe" then
		db.swipe = not db.swipe
		Print("cooldown swipe handling " .. (db.swipe and "enabled" or "disabled") .. ". Type /reload to fully apply.")
		RefreshAll()
	elseif msg == "debug" then
		local f = GetMouseFocus and GetMouseFocus()
		if not f or not f._state_type then
			Print("hover an ElvUI action button, then type /coa debug")
			return
		end
		local id = ButtonSpellID(f)
		Print(("button %s | type=%s action=%s | spellID=%s"):format(tostring(f:GetName()), tostring(f._state_type), tostring(f._state_action), tostring(id)))
		if id and GetSpellCharges then
			local c, m = GetSpellCharges(id)
			Print("GetSpellCharges -> " .. tostring(c) .. " / " .. tostring(m))
		end
		if f._state_type == "action" then
			Print("GetActionCharges(slot) -> " .. tostring(GetActionCharges and GetActionCharges(f._state_action)))
		end
	else
		Print("v" .. (GetAddOnMetadata(ADDON_NAME, "Version") or "?") .. " | charges " .. (db.enabled and "ON" or "OFF") .. ", swipe " .. (db.swipe and "ON" or "OFF"))
		Print("/coa on | off  - toggle charge display")
		Print("/coa swipe     - toggle cooldown swipe handling")
		Print("/coa debug     - inspect the action button under your mouse")
	end
end
